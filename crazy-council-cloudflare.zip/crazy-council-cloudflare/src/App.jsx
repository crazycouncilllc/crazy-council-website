import React from 'react';
import {
  ArrowRight,
  BadgeCheck,
  CheckCircle2,
  Flame,
  Handshake,
  Mail,
  MapPin,
  PackageCheck,
  Phone,
  Truck,
  Wrench,
} from 'lucide-react';
import { motion } from 'framer-motion';

const contactEmail = 'support@crazycouncilllc.com';
const contactPhoneDisplay = '352-723-7893';
const contactPhoneHref = 'tel:3527237893';
const HEADER_IMAGE = '/header.png';

const services = [
  {
    icon: <PackageCheck />,
    title: 'Retail Products',
    text: 'Customer-focused retail built around dependable products, practical value, and a brand that stands out.',
  },
  {
    icon: <Truck />,
    title: 'Sourcing & Fulfillment',
    text: 'A growing retail operation focused on finding products, managing suppliers, and serving customers with consistency.',
  },
  {
    icon: <Wrench />,
    title: 'IT Services',
    text: 'Crazy Council works alongside Gator-IT to help you find technology solutions, IT support, and services that fit your needs.',
  },
  {
    icon: <Handshake />,
    title: 'Custom Orders',
    text: 'Need something different? Send the idea, and Crazy Council can help bring bold custom merchandise concepts to life.',
  },
];

const steps = [
  'Build a strong retail foundation.',
  'Create a bold, recognizable brand.',
  'Serve customers with straight answers and dependable support.',
  'Work alongside Gator-IT to help provide IT solutions and services.',
];

function HeaderArtwork() {
  return (
    <div className="header-art-wrap" aria-label="Crazy Council LLC rustic outlaw header">
      <img className="header-art" src={HEADER_IMAGE} alt="Crazy Council LLC rustic outlaw header" />
    </div>
  );
}

function ContactForm() {
  const web3FormsKey = import.meta.env.VITE_WEB3FORMS_ACCESS_KEY || '';
  const formAction = web3FormsKey ? 'https://api.web3forms.com/submit' : `mailto:${contactEmail}`;

  return (
    <form className="contact-card" action={formAction} method="POST">
      {web3FormsKey && <input type="hidden" name="access_key" value={web3FormsKey} />}
      <input type="hidden" name="subject" value="New Crazy Council LLC Website Lead" />
      <input type="hidden" name="from_name" value="Crazy Council LLC Website" />

      <label>
        Name
        <input name="name" required placeholder="Your name" />
      </label>

      <label>
        Email
        <input name="email" type="email" required placeholder="you@example.com" />
      </label>

      <label>
        Phone
        <input name="phone" placeholder="Optional phone number" />
      </label>

      <label>
        What are you looking for?
        <textarea name="message" required placeholder="Tell us what product, service, or IT need you have." />
      </label>

      <button className="primary full" type="submit">Send Message</button>

      <p className="small-note">
        To send directly to your Microsoft 365 mailbox, add a Web3Forms access key to Cloudflare Pages as VITE_WEB3FORMS_ACCESS_KEY.
      </p>
    </form>
  );
}

export default function App() {
  return (
    <div className="site-shell">
      <header className="site-header">
        <HeaderArtwork />
        <div className="topbar">
          <div className="header-contact">
            <a href={`mailto:${contactEmail}`}><Mail size={18} /> {contactEmail}</a>
            <a href={contactPhoneHref}><Phone size={18} /> {contactPhoneDisplay}</a>
          </div>

          <nav aria-label="Main navigation">
            <a href="#home">Home</a>
            <a href="#services">Shop</a>
            <a href="#about">About Us</a>
            <a href="#process">Custom Orders</a>
            <a href="#contact">Contact</a>
          </nav>
        </div>
      </header>

      <main id="home">
        <section className="hero">
          <div className="grain" />

          <motion.div
            className="hero-copy"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="eyebrow"><Flame size={18} /> Rustic retail with an outlaw edge</div>
            <h1>Built Different. Driven Forward.</h1>
            <p>
              Crazy Council LLC is a retail-focused company built around quality products, honest service, and practical solutions. We also work alongside Gator-IT to help customers find the right IT services for their needs.
            </p>
            <div className="hero-actions">
              <a className="primary" href="#contact">Contact Crazy Council <ArrowRight size={18} /></a>
              <a className="secondary" href="#services">See What We Do</a>
            </div>
          </motion.div>

          <motion.div
            className="hero-card"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.12 }}
          >
            <div className="mini-logo"><span>C</span><span>C</span></div>
            <h2>Retail today. Services that grow with you.</h2>
            <ul>
              <li><CheckCircle2 /> Retail products and customer support</li>
              <li><CheckCircle2 /> Product sourcing and brand growth</li>
              <li><CheckCircle2 /> IT service support alongside Gator-IT</li>
              <li><CheckCircle2 /> Built for future online store expansion</li>
            </ul>
          </motion.div>
        </section>

        <section className="section" id="services">
          <div className="section-title">
            <p>Services</p>
            <h2>A retail brand with real-world solutions.</h2>
          </div>
          <div className="grid four">
            {services.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="split" id="about">
          <div>
            <p className="label">About</p>
            <h2>Bold, practical, and built to grow.</h2>
          </div>
          <div className="copy">
            <p>Crazy Council LLC is creating a retail presence with a strong identity and room to expand. The company is designed around product sales, customer relationships, and practical service connections.</p>
            <p>For technology needs, Crazy Council works alongside Gator-IT to help connect customers with dependable IT support, business technology solutions, and guidance that fits their situation.</p>
          </div>
        </section>

        <section className="section" id="process">
          <div className="section-title">
            <p>Our Direction</p>
            <h2>Simple steps. Strong foundation.</h2>
          </div>
          <div className="steps">
            {steps.map((step, index) => (
              <div className="step" key={step}>
                <span>{index + 1}</span>
                <p>{step}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="cta-block">
          <div>
            <BadgeCheck />
            <h2>Need products, support, or IT direction?</h2>
            <p>Start with Crazy Council. For technology needs, we work alongside Gator-IT to help find the right path forward.</p>
          </div>
          <a className="dark-button" href="#contact">Start the Conversation</a>
        </section>

        <section className="contact-section" id="contact">
          <div className="contact-copy">
            <p className="label">Contact</p>
            <h2>Connect with Crazy Council LLC.</h2>
            <p>The form is ready to connect to your Microsoft 365 inbox using a Web3Forms key in Cloudflare Pages.</p>
            <div className="contact-lines">
              <p><Phone /> {contactPhoneDisplay}</p>
              <p><Mail /> {contactEmail}</p>
              <p><MapPin /> Serving customers across Florida and beyond</p>
            </div>
          </div>
          <ContactForm />
        </section>
      </main>

      <footer>
        <div className="footer-brand">Crazy Council LLC</div>
        <p>© {new Date().getFullYear()} Crazy Council LLC. All rights reserved.</p>
      </footer>
    </div>
  );
}
